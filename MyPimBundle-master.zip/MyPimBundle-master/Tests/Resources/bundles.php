<?php

return [
    Akeneo\Test\IntegrationTestsBundle\AkeneoIntegrationTestsBundle::class => ['test' => true],
    Pim\Bundle\CustomEntityBundle\PimCustomEntityBundle::class => ['test' => true],
    Acme\Bundle\CustomBundle\AcmeCustomBundle::class => ['test' => true]
];
