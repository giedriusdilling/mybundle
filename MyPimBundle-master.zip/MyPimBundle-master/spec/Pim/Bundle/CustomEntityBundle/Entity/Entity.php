<?php

namespace spec\Pim\Bundle\CustomEntityBundle\Entity;

class Entity
{
    public function getId()
    {
    }
}
