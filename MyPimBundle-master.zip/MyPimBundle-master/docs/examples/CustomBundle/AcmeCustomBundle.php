<?php

namespace Acme\Bundle\CustomBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * @author Romain Monceau <romain@akeneo.com>
 */
class AcmeCustomBundle extends Bundle
{
}
