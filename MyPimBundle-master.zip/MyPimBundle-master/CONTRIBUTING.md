Thank you to read and sign the following contributor agreement http://www.akeneo.com/contributor-license-agreement/
